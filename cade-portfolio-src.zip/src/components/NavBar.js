// import { Link } from "react-scroll";
import "./NavBar.css";
import logo from "./airborne-innovations-logo.png";
import { useNavigate } from "react-router-dom";
import React, { useState } from "react";

function NavBar() {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const handleHomeClick = () => {
    navigate("/Home");
    setIsOpen(false); // Close menu after navigation
  };

  const handleProjectsClick = () => {
    navigate("/Projects");
    setIsOpen(false); // Close menu after navigation
  };

  return (
    <div className={`navbar ${isOpen ? "open" : ""}`}>
      <img src={logo} alt="Airborne Innovations Logo" height="123" />
      <div className="hamburger-menu" onClick={toggleMenu}>
        <span></span>
        <span></span>
        <span></span>
      </div>
      <button onClick={handleHomeClick}>Home</button>
      <button onClick={handleProjectsClick}>Projects</button>
    </div>
  );
}

export default NavBar;
