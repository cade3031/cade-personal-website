// import React from "react";
// import myImage from "./myImage.jpeg";

// function ProfilePic() {
//     return (
//         <div>
//             <img src={myImage} alt="myImage" />
//         </div>
//     )
// }

// export default ProfilePic;